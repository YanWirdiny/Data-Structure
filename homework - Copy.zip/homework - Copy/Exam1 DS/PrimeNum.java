//import java.util.Scanner;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Class Primnum
 */
public class PrimeNum{
     public static void main(String []args) throws IOException{
       // element
       Scanner input = new Scanner(System.in);
       System.out.println("Enter the a value less than 100000000");
       long n = input.nextLong();


        java.util.List<Long> TheList = loadPrimesFromFile("number.dat");
        int count = 0 ; 
        int SquareRoot=1;
        long number= 2;


        while(number<= n){

            if(SquareRoot * SquareRoot  < number){SquareRoot++;}
             boolean ThePrime = true;

            for(int i = 0 ;i < TheList.size() && TheList.get(i) <= SquareRoot;i++
            ){
                if(  number % TheList.get(i)== 0){
                    ThePrime = false;
                    break;
                }
            }
            if(ThePrime){
                count++;
                if(!TheList.contains(number)){
                    
                    TheList.add(number);

                }
            

            }
           number++;
        }

        System.out.println("the total prime number are "+ count);
        System.out.println("please check the file ");
        
       BufferedWriter br = new BufferedWriter(new FileWriter("number.dat"));
for (long str : TheList) {
    br.write(str + System.lineSeparator());
}
br.close();

     
}

    private static List<Long> loadPrimesFromFile(String fileName) throws IOException {
        List<Long> TheList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                TheList.add(Long.parseLong(line));
            }
        }
        return TheList;}

}